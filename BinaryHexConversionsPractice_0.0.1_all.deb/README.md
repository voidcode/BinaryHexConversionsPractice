# BinaryHexConversionsPractice
Decimal to binary and hex conversions practice app.

![BinaryHexConversionsPractice](https://raw.githubusercontent.com/voidcode/BinaryHexConversionsPractice/master/PR/ui.gif)


#Run this app

```
  cd /tmp && wget https://github.com/voidcode/BinaryHexConversionsPractice/archive/master.zip && unzip master.zip && cd BinaryHexConversionsPractice-master/ && python main.py
```


